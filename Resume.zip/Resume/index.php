<?php
// Redirect the user to the controller's index.php file
header("Location: Controller/index.php");
exit();  // Stop further script execution
?>