<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Trong_Ly_Resume</title>
        <link rel="stylesheet" href="../style/style.css">
    </head>
    <body>
        <header>
            <h1>Trong Ly's Resume</h1>
            <p>Software Engineer | 858 S Eliot St, Denver, CO, USA | 720-266-0614 | tronglyhieu1997@gmail.com</p>
        </header>
    </body>