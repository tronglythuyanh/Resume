<?php
include_once '../Model/function.php';
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
switch ($action) {
    case 'homepage':
        include '../View/homepage.php';
        break;
    default:
        header('Location: index.php?action=homepage');
        break;


}